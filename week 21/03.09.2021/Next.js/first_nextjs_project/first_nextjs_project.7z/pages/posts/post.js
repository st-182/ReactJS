import React from "react";

const Post = () => {
  return (
    <div>
      <h1>Post1</h1>
    </div>
  );
};

export default Post;
