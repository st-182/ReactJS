import React from "react";
import "./TopBar.css";

const TopBar = () => {
  return <div className="topbar"></div>;
};

export default TopBar;
