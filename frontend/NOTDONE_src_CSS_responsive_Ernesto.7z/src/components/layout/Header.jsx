import React from "react";
import TopBar from "../TopBar";
import "./Header.css";

const Header = () => {
  return (
    <header>
      <TopBar />
      <div>Header</div>
    </header>
  );
};

export default Header;
