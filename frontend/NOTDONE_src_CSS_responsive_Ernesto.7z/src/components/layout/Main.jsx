import React from "react";
import Content from "../Content";
import Feature from "../Feature";
import SignUp from "../SignUp";

const Main = () => {
  return (
    <main>
      {/* <Content />
      <SignUp /> */}
      <Feature classNames="ft-bg-blue" />
      <Feature classNames="ft-bg-red" />
      <Feature classNames="ft-bg-green" />
    </main>
  );
};

export default Main;
