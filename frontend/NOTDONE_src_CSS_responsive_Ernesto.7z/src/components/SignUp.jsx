import React from "react";

const SignUp = () => {
  return <div>a</div>;
};

export default SignUp;
