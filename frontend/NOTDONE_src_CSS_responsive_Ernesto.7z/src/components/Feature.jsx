import React from "react";

const Feature = ({ classNames }) => {
  return (
    <div>
      <h1>a</h1>
    </div>
  );
};

export default Feature;
