import React from "react";

const Content = () => {
  return <div>a</div>;
};

export default Content;
