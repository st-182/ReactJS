import React from "react";
import CompB1a1 from "./CompB1a1";

const CompB1a = () => {
  return (
    <>
      <CompB1a1 />
    </>
  );
};

export default CompB1a;
