import React from "react";
import CompB1a from "./CompB1a";

const CompB1 = () => {
  return (
    <>
      <CompB1a />
    </>
  );
};

export default CompB1;
