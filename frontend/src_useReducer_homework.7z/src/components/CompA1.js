import React from "react";
import CompA1a from "./CompA1a";
import CompA1b from "./CompA1b";
import CompA1c from "./CompA1c";

const CompA1 = () => {
  return (
    <>
      <CompA1a />
      <CompA1c />
      <CompA1b />
    </>
  );
};

export default CompA1;
