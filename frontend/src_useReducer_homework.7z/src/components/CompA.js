import React from "react";
import CompA1 from "./CompA1";

const CompA = () => {
  return (
    <>
      <CompA1 />
    </>
  );
};

export default CompA;
