import React from 'react';
import CompD from './CompD';

const CompB = () => {
  return (
    <>
      <h2>Component B</h2>
      <CompD />
    </>
  );
};

export default CompB;
