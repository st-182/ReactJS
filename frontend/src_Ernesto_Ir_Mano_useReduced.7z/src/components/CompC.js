import React from 'react';
import CompE from './CompE';

const CompC = () => {
  return (
    <>
      <h2>Component C</h2>
      <CompE />
    </>
  );
};

export default CompC;
