import React, { useState, useContext } from "react";
import { ClicksContext } from "../App";

const CompA = () => {
  // Hooks
  // -- state
  // ---- global
  const clicksContext = useContext(ClicksContext);
  const { dispatch, state } = clicksContext;
  // ---- local
  const [buttonClicks, setButtonClicks] = useState(0);

  // Custom funtions
  const clickHandler = () => {
    // changing global state
    dispatch({ type: "INCREMENT" });
    // changing local state
    setButtonClicks(buttonClicks + 1);
  };
  const clickHandler2 = () => {
    // changing global state
    dispatch({ type: "DECREMENT" });
    // changing local state
    setButtonClicks(buttonClicks - 1);
  };
  return (
    <>
      <h2>Component A</h2>
      <p>{buttonClicks}</p>
      <p>{state.clicks}</p>
      <button onClick={clickHandler}>+</button>
      <button onClick={clickHandler2}>-</button>
    </>
  );
};

export default CompA;
