import React from 'react';
import CompF from './CompF';

const CompE = () => {
  return (
    <>
      <h3>Component E</h3>
      <CompF />
    </>
  );
};

export default CompE;
