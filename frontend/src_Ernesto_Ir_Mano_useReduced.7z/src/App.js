// import Counter from './components/Counter';
import React, { useReducer } from "react";

// Components
import CompA from "./components/CompA";
import CompB from "./components/CompB";
import CompC from "./components/CompC";

//ACTIONS - global, Unchanging variable
const ACTIONS = {
  increment: "INCREMENT",
  decrement: "DECREMENT",
};

// Context (for managing global state)
export const ClicksContext = React.createContext();

// useReducer inital state
const initialClickState = { clicks: 0 };
// useReducer reducer funtion to manage initialClickState
const clickReducer = (state, action) => {
  switch (action.type) {
    case "INCREMENT":
      return { clicks: state.clicks + 1 };
    case "DECREMENT":
      return { clicks: state.clicks - 1 };
    default:
      return state;
  }
};

function App() {
  const [state, dispatch] = useReducer(clickReducer, initialClickState);

  return (
    <div className="App">
      {/* <Counter /> */}
      <ClicksContext.Provider value={{ dispatch, state }}>
        <h1>
          Buttons cliked <u>{state.clicks}</u> times in total
        </h1>

        <CompA />
        <CompB />
        <CompC />
      </ClicksContext.Provider>
    </div>
  );
}

export default App;
