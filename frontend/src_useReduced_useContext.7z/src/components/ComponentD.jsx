import React from "react";
// import GlobalState from ''
const ComponentD = () => {
  return (
    <div>
      <h3>Component D</h3>
    </div>
  );
};

export default ComponentD;
