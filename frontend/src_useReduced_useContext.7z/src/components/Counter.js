import React, { useReducer } from "react";

let initialState = { count: 0, message: "" };
const reducer = (state, action) => {
  switch (action.type) {
    case "INCREMENT":
      if (state.count <= 9) {
        return { ...state, count: state.count + 1, message: "" };
      }
      return { ...state, message: "max limit reached" };
      break;
    case "DECREMENT":
      if (state.count > 0) {
        return { ...state, count: state.count - 1, message: "" };
      }
      return { ...state, message: "min limit reached" };

      break;

    default:
      break;
  }
};

const Counter = () => {
  //Hooks
  // -- state
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <div>
      <h3>Count: {state.count}</h3>
      <p>{state.message}</p>
      <button className="btn" onClick={() => dispatch({ type: "DECREMENT" })}>
        -
      </button>
      <button className="btn" onClick={() => dispatch({ type: "INCREMENT" })}>
        +
      </button>
    </div>
  );
};

export default Counter;
