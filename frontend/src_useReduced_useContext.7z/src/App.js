import React, { useContext, useReducer } from "react";
import ComponentA from "./components/ComponentA";
import ComponentB from "./components/ComponentB";
import ComponentC from "./components/ComponentC";
import Counter from "./components/Counter";

export const GlobalState = React.createContext();
//useReducer
let initialClickState = { clicks: 0 };
const ClickReducer = (action, state) => {
  switch (action.type) {
    case "INCREMENT":
      return { clicks: state.clicks + 1 };
      break;

    default:
      break;
  }
};

function App() {
  const [state, dispatch] = useReducer(ClickReducer, initialClickState);

  return (
    <div className="grid">
      {/* <Counter /> */}
      <ComponentA />
      <ComponentC />
      <ComponentB />
    </div>
  );
}

export default App;
